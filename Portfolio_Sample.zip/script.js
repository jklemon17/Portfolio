// REQUIRED FILE FOR ANIMATIONS

$(document).ready(function() {
  'use strict';

  new WOW().init();
});
